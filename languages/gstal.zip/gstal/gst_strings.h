#ifndef _BCSTRINGS_H
#define _BCSTRINGS_H

char *strdup(const char*);

#endif
