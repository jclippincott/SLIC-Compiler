#ifndef DEBUG
#define DEBUG 0
#endif
